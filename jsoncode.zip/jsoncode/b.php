<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Convert  Object to String</title>
</head>
<body>
    <script>
       
        var b=
        {
    "id": "89J34380C64769511",
    "intent": "CAPTURE",
    "status": "COMPLETED",
    "payment_source": {
        "paypal": {
            "email_address": "anubhav@vedsu.com",
            "account_id": "FSHK6GUK4BLLC",
            "name": {
                "given_name": "Anubhav",
                "surname": "Jaiswal"
            },
            "address": {
                "country_code": "US"
            }
        }
    },
    "purchase_units": [
        {
            "reference_id": "default",
            "amount": {
                "currency_code": "USD",
                "value": "229.00",
                "breakdown": {
                    "item_total": {
                        "currency_code": "USD",
                        "value": "229.00"
                    },
                    "shipping": {
                        "currency_code": "USD",
                        "value": "0.00"
                    },
                    "handling": {
                        "currency_code": "USD",
                        "value": "0.00"
                    },
                    "insurance": {
                        "currency_code": "USD",
                        "value": "0.00"
                    },
                    "shipping_discount": {
                        "currency_code": "USD",
                        "value": "0.00"
                    },
                    "discount": {
                        "currency_code": "USD",
                        "value": "0.0"
                    }
                }
            },
            "payee": {
                "email_address": "sb-z8rom22836442@business.example.com",
                "merchant_id": "96W9NJPRRXD94"
            },
            "description": "Purchased from OnlineAudioConference",
            "soft_descriptor": "PAYPAL *TEST STORE",
            "items": [
                {
                    "name": "Texting and E-mail with Patients - HIPAA and Access Preferences for Patients",
                    "unit_amount": {
                        "currency_code": "USD",
                        "value": "229.00"
                    },
                    "tax": {
                        "currency_code": "USD",
                        "value": "0.00"
                    },
                    "quantity": "1",
                    "sku": "251.1172"
                }
            ],
            "shipping": {
                "name": {
                    "full_name": "Anubhav Jaiswal"
                },
                "address": {
                    "address_line_1": "3524 Silverside Road,",
                    "admin_area_2": "Wilmington",
                    "admin_area_1": "DE",
                    "postal_code": "19810",
                    "country_code": "US"
                }
            },
            "payments": {
                "captures": [
                    {
                        "id": "1MH4770049608801H",
                        "status": "COMPLETED",
                        "amount": {
                            "currency_code": "USD",
                            "value": "229.00"
                        },
                        "final_capture": true,
                        "seller_protection": {
                            "status": "NOT_ELIGIBLE"
                        },
                        "seller_receivable_breakdown": {
                            "gross_amount": {
                                "currency_code": "USD",
                                "value": "229.00"
                            },
                            "paypal_fee": {
                                "currency_code": "USD",
                                "value": "10.89"
                            },
                            "net_amount": {
                                "currency_code": "USD",
                                "value": "218.11"
                            }
                        },
                        "links": [
                            {
                                "href": "https:\/\/api.sandbox.paypal.com\/v2\/payments\/captures\/1MH4770049608801H",
                                "rel": "self",
                                "method": "GET"
                            },
                            {
                                "href": "https:\/\/api.sandbox.paypal.com\/v2\/payments\/captures\/1MH4770049608801H\/refund",
                                "rel": "refund",
                                "method": "POST"
                            },
                            {
                                "href": "https:\/\/api.sandbox.paypal.com\/v2\/checkout\/orders\/89J34380C64769511",
                                "rel": "up",
                                "method": "GET"
                            }
                        ],
                        "create_time": "2022-12-07T08:11:45Z",
                        "update_time": "2022-12-07T08:11:45Z"
                    }
                ]
            }
        }
    ],
    "payer": {
        "name": {
            "given_name": "Anubhav",
            "surname": "Jaiswal"
        },
        "email_address": "anubhav@vedsu.com",
        "payer_id": "FSHK6GUK4BLLC",
        "address": {
            "country_code": "US"
        }
    },
    "create_time": "2022-12-07T08:11:06Z",
    "update_time": "2022-12-07T08:11:45Z",
    "links": [
        {
            "href": "https:\/\/api.sandbox.paypal.com\/v2\/checkout\/orders\/89J34380C64769511",
            "rel": "self",
            "method": "GET"
        }
    ]
}
        
        // document.write(a.Age);
        var chdata=JSON.stringify(b);
        window.location="send.php?values="+chdata;
    </script>
</body>
</html>