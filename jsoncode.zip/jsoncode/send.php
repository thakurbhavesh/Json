<?php
// echo $_GET['values'];
if(isset($_GET['values']))
{
 
    $showdata=json_decode($_GET['values'], true);
    // echo "<pre>";
    // print_r($showdata);
    echo $showdata['id']."<br>";
    echo $showdata['status']."<br>";
    echo $showdata['payment_source']['paypal']['email_address']."<br>";
    echo $showdata['payment_source']['paypal']['name']['given_name']."<br>";
     echo $showdata['payment_source']['paypal']['address']['country_code']."<br>";
    // echo "<pre>";
    //  print_r($showdata['purchase_units'])."<br>";
     echo $showdata['purchase_units'][0]['reference_id']."<br>";
     echo $showdata['purchase_units'][0]['amount']['breakdown']['item_total']['currency_code']."<br>";
     echo $showdata['purchase_units'][0]['amount']['breakdown']['shipping']['currency_code']."<br>";
     echo $showdata['purchase_units'][0]['amount']['breakdown']['handling']['currency_code']."<br>";
     echo $showdata['purchase_units'][0]['amount']['breakdown']['insurance']['value']."<br>";
     echo $showdata['purchase_units'][0]['amount']['breakdown']['discount']['value']."<br>";
    echo $showdata['purchase_units'][0]['payee']['email_address']."<br>";
    echo $showdata['purchase_units'][0]['payee']['merchant_id']."<br>";
    echo $showdata['purchase_units'][0]['description']."<br>";
    echo $showdata['purchase_units'][0]['items'][0]['name']."<br>";
    echo $showdata['purchase_units'][0]['items'][0]['unit_amount']['currency_code']."<br>";
    echo $showdata['purchase_units'][0]['items'][0]['unit_amount']['value']."<br>";
    echo $showdata['purchase_units'][0]['items'][0]['tax']['value']."<br>";
    echo $showdata['purchase_units'][0]['items'][0]['quantity']."<br>";
    echo $showdata['purchase_units'][0]['items'][0]['sku']."<br>";
    echo $showdata['purchase_units'][0]['shipping']['name']['full_name']."<br>";
    echo $showdata['purchase_units'][0]['shipping']['address']['address_line_1']."<br>";
    echo $showdata['purchase_units'][0]['shipping']['address']['admin_area_2']."<br>";
    echo $showdata['purchase_units'][0]['shipping']['address']['admin_area_1']."<br>";
    echo $showdata['purchase_units'][0]['shipping']['address']['postal_code']."<br>";
    echo $showdata['purchase_units'][0]['shipping']['address']['country_code']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['id']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['status']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['amount']['currency_code']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['amount']['value']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['final_capture']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['seller_protection']['status']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['seller_receivable_breakdown']['gross_amount']['value']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['seller_receivable_breakdown']['paypal_fee']['value']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['links'][0]['href']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['links'][0]['rel']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['links'][0]['method']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['links'][1]['href']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['links'][1]['rel']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['links'][1]['method']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['links'][2]['href']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['links'][2]['rel']."<br>";
    echo $showdata['purchase_units'][0]['payments']['captures'][0]['links'][2]['method']."<br>";
     echo $showdata['purchase_units'][0]['payments']['captures'][0]['create_time']."<br>";
     echo $showdata['payer']['name']['given_name']."<br>";
     echo $showdata['payer']['name']['surname']."<br>";
     echo $showdata['payer']['email_address']."<br>";
     echo $showdata['payer']['payer_id']."<br>";
     echo $showdata['payer']['address']['country_code']."<br>";
     echo $showdata['create_time']."<br>";
     echo $showdata['update_time']."<br>";
     echo $showdata['links'][0]['href']."<br>";
     echo $showdata['links'][0]['rel']."<br>";
     echo $showdata['links'][0]['method']."<br>";




}
?>