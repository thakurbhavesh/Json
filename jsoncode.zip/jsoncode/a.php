<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>
    <script>
        var a = {
            "name": "bhavesh",
            "age": 24
        }
        a.name = "Shiva"; //Modify a value
        a.dob = "25/03/2003"; //Add a new key value pair
        // delete a.name;                //Delete a key value   
        // Single Data Fetch

        // document.write(a.age);   24
        // document.write(a.name);   bhavesh
        // document.write(a.NAME);   undefined

        // Fetch All Record Via Loop
        for (showalldata in a) {
            // document.writeln(showalldata);   //print key like name,age
            // document.writeln(a[showalldata]);   //print value like bhavesh,24
        }

        var b = {
            "fifa": [{
                    "country": "India"
                },
                {
                    "country": "USA"
                }
            ]
        }

        // Fetch Array of object

        // document.write(b.fifa[0].country);   //Fetch Data Index Wise     o/p  India
        // document.write(b.fifa[1].country);   //Fetch Data Index Wise     o/p  USA


        var c = {
            "fifa": [{
                    "country": "India",
                    "Code": "IND"
                },
                {
                    "country": "USA",
                    "code": "US"
                }
            ]
        }
        // document.write(c.fifa[0].Code);
        for (x in c.fifa) {
            // document.write(x);   // Index Print
            for (y in c.fifa[x]) {
                // document.write(y);    //Print Key
                // document.write(c.fifa[x][y]+"<br>");           //print allvalue

            }
        }
    </script>
</body>

</html>